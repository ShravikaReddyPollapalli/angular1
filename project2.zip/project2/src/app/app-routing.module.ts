import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DepartmentComponent } from './department/department.component';
import { EmployeeComponent } from './employee/employee.component';
import { HeaderComponent } from './header/header.component';
import { DataComponent } from './data/data.component';
import { FormsModule } from '@angular/forms';
import { ReactComponent } from './react/react.component';
// import { TempComponent } from './temp/temp.component';

const routes: Routes = [
  {path:'department',component:DepartmentComponent},
  {path:'employee',component:EmployeeComponent},
  {path:'header',component:HeaderComponent},
  {path:'data',component:DataComponent},
  {path:'react' ,component:ReactComponent},
  // {path:'temp',component:TempComponent}

  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
