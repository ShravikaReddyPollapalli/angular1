import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tree',
  templateUrl: './tree.component.html',
  styleUrls: ['./tree.component.css']
})
export class TreeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  trees1 = {
    name: "mango",
    place: "garden"
  }
  trees2 = {
    name: "neem",
    place: "forest"
  }
  // arrayOf = [this.trees1.name,this.trees1.place,this.trees2.name,this.trees2.place];
  arrayOf = [this.trees1, this.trees2]
  studentMarks = 23;
  trees: string[] = ["apple", "neem", "mango"]
}
