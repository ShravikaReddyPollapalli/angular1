import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
 import { HeaderComponent } from './header/header.component';
 import { DataComponent } from './data/data.component';
import { DepartmentComponent } from './department/department.component';
import { EmployeeComponent } from './employee/employee.component';


import { ReactComponent } from './react/react.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// import { TempComponent } from './temp/temp.component';



let routes:Routes=[
    {path:'header',component:HeaderComponent},
   {path:'department',component:DepartmentComponent},
   {path:'employee' , component:EmployeeComponent},
   {path:'data',component:DataComponent},
   {path:'react',component:ReactComponent},
  //  {path:'temp',component:TempComponent}
   
   
]
@NgModule({
  declarations: [
    AppComponent,
     HeaderComponent,
    DepartmentComponent,
    EmployeeComponent
    ,DataComponent,  ReactComponent,
    //  TempComponent, 
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
     RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
