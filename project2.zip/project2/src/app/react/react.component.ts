import { Component, OnInit } from '@angular/core';
import {ReactiveFormsModule, FormBuilder, Validators, FormControl } from '@angular/forms';
@Component({
  selector: 'app-react',
  templateUrl: './react.component.html',
  styleUrls: ['./react.component.css']
})
export class ReactComponent implements OnInit {

  constructor(private fb: FormBuilder) { }

  
    loginGroup;
  ngOnInit() {
   this.loginGroup= this.fb.group({
      name:[null,[Validators.required,Validators.minLength(5)]],
      password:["",[Validators.required,Validators.minLength(5)]],
      skills: this.fb.array([])
    })
  }
  getSkills() {
    return this.loginGroup.get('skills');
  }
  addSkills() {
    this.loginGroup.get('skills').push(new FormControl());
  }
  removeSkills(i: number) {
    this.loginGroup.get('skills').removeAt(i);
  }

  }


