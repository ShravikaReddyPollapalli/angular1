package com.jfsfeb.stockmanagementsystem.controller;

public class MainController {
	public static void main(String[] args) {
		StockController.operations();
	}
}
