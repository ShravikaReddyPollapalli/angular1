package com.jfsfeb.stockmanagementsystem.controller;

import java.util.List;
import java.util.Random;
import java.util.Scanner;
import com.jfsfeb.stockmanagementsystem.dto.AdminInfoBean;
import com.jfsfeb.stockmanagementsystem.dto.ManagerInfoBean;
import com.jfsfeb.stockmanagementsystem.dto.StockInfoBean;
import com.jfsfeb.stockmanagementsystem.factory.Factory;
import com.jfsfeb.stockmanagementsystem.repository.StockRepository;
import com.jfsfeb.stockmanagementsystem.service.CompanyService;
import lombok.extern.log4j.Log4j;

@Log4j
public class ManagerController {
	public void companyManagerController() {

		StockRepository.addToDataBase();

		long mobileNumber = 0;

		String password = null;

		int stockId = 0;
		String stockName = null;
		String stockType = null;
		int quantity = 0;
		double stockCost = 0.0;

		String loginMail = null;
		String loginPassword = null;

		

		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);

		CompanyService service2 = Factory.getCompanyServiceImplInstance();
		log.info("welcome to company manger blog,plsease login");
		log.info("Enter Email :");
		loginMail = scanner.next();
		log.info("Enter Password :");
		loginPassword = scanner.next();
		try {
			@SuppressWarnings("unused")
			ManagerInfoBean login = service2.loginManager(loginMail, loginPassword);
			log.info("You have logged in successfully");

			do {
				try {
					log.info("-----------------------------------");
					log.info("Press 1 to change password");
					log.info("press 2 to add stock");
					log.info("press 3 to update the type");
					log.info("press 4 to update the price ");
					log.info("press 5 to update the Quantity");
					log.info("press 6 to remove stock");
					log.info("press 7 to search stock by stock type");
					log.info("press 8 to search stock by product name");
					log.info("press 9 to get the all stock");
					log.info("press 10 to Logout");

					int choice = scanner.nextInt();
					switch (choice) {

					case 1:

						log.info("Enter Mobile :");
						mobileNumber = scanner.nextLong();

						log.info("Enter new  Password :");
						password = scanner.next();

						if (mobileNumber == 0) {
							log.info("Enter the Valid mobilenumber");
						} else {

							Random random = new Random();
							int otp = random.nextInt(10000);
							log.info(otp < 0 ? otp * -1 : otp);
							log.info("please ,enter otp ");
							int typeOtp = scanner.nextInt();
							if (otp == typeOtp) {

								AdminInfoBean bean = new AdminInfoBean();
								bean.setMobileNumber(mobileNumber);
								bean.setPassword(password);
								boolean update = service2.changePassword(mobileNumber, password);
								if (update) {
									log.info("password updated succesfully");

								} else {
									log.error("passwrod is not updated");
								}
							} else {
								log.error("otp mismatched");
							}
						}

						break;

					case 2:

						log.info("Enter stock-ID :");
						stockId = scanner.nextInt();
						log.info("Enter stock Name :");
						stockName = scanner.next();
						log.info("Enter Type :");
						stockType = scanner.next();
						log.info("enter Price");
						stockCost = scanner.nextDouble();
						log.info("enter no of products");
						quantity = scanner.nextInt();
						StockInfoBean bean1 = new StockInfoBean();
						bean1.setId(stockId);
						bean1.setProductName(stockName);
						bean1.setPrice(stockCost);
						bean1.setType(stockType);
						bean1.setQuantity(quantity);
						boolean check2 = service2.addStocks(bean1);
						if (check2) {
							log.info("stock Added");
							log.info(String.format("%-5s %-20s %-20s %-20s %s", bean1.getId(), bean1.getProductName(),
									bean1.getPrice(), bean1.getType(), bean1.getQuantity()));
						} else {
							log.info("stock already exist");
						}

						break;

					case 3:
						log.info("enter  Stock_Id");
						int sId = scanner.nextInt();
						log.info("Enter the new stock_type :");
						String sType = scanner.next();

						if (sId == 0) {
							log.info("Enter the Valid stock_id");
						} else {
							StockInfoBean bean6 = new StockInfoBean();
							bean6.setId(sId);
							bean6.setType(sType);
							boolean update = service2.updateStockTypeById(sId, sType);
							if (update) {
								log.info("stock updated succesfully");
							} else {
								log.error("stock is not updated");
							}
						}

						break;
					case 4:
						log.info("enter new Stock_Name");
						String sName = scanner.next();
						log.info("Enter the  stock_Cost :");
						double sCost = scanner.nextDouble();

						if (sName == null) {
							log.info("Enter the Valid stock_Name");
						} else {
							StockInfoBean bean6 = new StockInfoBean();
							bean6.setPrice(sCost);
							bean6.setProductName(sName);
							boolean update = service2.updateStockPriceByName(sName, sCost);
							if (update) {
								log.info("stock updated succesfully");
							} else {
								log.error("stock is not updated");
							}
						}

						break;

					case 5:
						log.info("enter new Stock_Type");
						String sType1 = scanner.next();
						log.info("Enter the  no of stock:");
						int count = scanner.nextInt();

						if (sType1 == null) {
							log.info("Enter the Valid stock_type");
						} else {
							StockInfoBean bean6 = new StockInfoBean();
							bean6.setType(sType1);
							bean6.setQuantity(count);
							boolean update = service2.updateStockQuantityByType(sType1, count);
							if (update) {
								log.info("stock updated succesfully");
							} else {
								log.error("stock is not updated");
							}
						}

						break;

					case 6:
						log.info("Enter the stock_Id to delete :");
						int stockId1 = scanner.nextInt();
						if (stockId1 == 0) {
							log.info("Enter the Valid stock_Id");
						} else {
							StockInfoBean bean6 = new StockInfoBean();
							bean6.setId(stockId);
							boolean remove = service2.removeStocks(stockId);
							if (remove) {
								log.error("The stock is removed");
							} else {
								log.error("The stock is not removed");
							}
						}
						break;

					case 7:

						log.info("  Search the stock by the type :");
						String stockType1 = scanner.next();

						List<StockInfoBean> stockType2 = service2.searchStockByType(stockType1);
						log.info(String.format("%-5s %-20s %-20s %-20s %s", "Book-Id", "company", "cost",
								"no of products", "type of stock"));
						for (StockInfoBean StockInfoBean : stockType2) {
							if (StockInfoBean != null) {
								log.info(String.format("%-5s %-20s %-20s %-20s %s", StockInfoBean.getId(),
										StockInfoBean.getProductName(), StockInfoBean.getPrice(),
										StockInfoBean.getQuantity(), StockInfoBean.getType()));
							} else {
								log.info("No stocks are available with this type.");
							}
						}

						break;

					case 8:

						log.info("Search the stock by the company Name:");
						String comName = scanner.next();

						List<StockInfoBean> company = service2.searchStockByName(comName);
						log.info(String.format("%-5s %-20s %-20s %-20s %s", "stock-Id", "company", "cost",
								"no of products", "type of stock"));
						for (StockInfoBean StockInfoBean : company) {

							if (StockInfoBean != null) {

								log.info(String.format("%-5s %-20s %-20s %-20s %s", StockInfoBean.getId(),
										StockInfoBean.getProductName(), StockInfoBean.getPrice(),
										StockInfoBean.getQuantity(), StockInfoBean.getType()));

							} else {
								log.error("No stocks are available with this companyname");
							}
						}

						break;

					case 9:
						List<StockInfoBean> info = service2.getStockDetails();
						log.info(String.format("%-5s %-20s %-20s %-20s %s", "Book-Id", "company", "cost",
								"no of products", "type of stock"));
						for (StockInfoBean StockInfoBean : info) {

							if (StockInfoBean != null) {
								log.info(String.format("%-5s %-20s %-20s %-20s %s", StockInfoBean.getId(),
										StockInfoBean.getProductName(), StockInfoBean.getPrice(),
										StockInfoBean.getQuantity(), StockInfoBean.getType()));

							} else {
								log.info("stock info is not present");
							}
						}
						break;

					case 10:
						companyManagerController();
						break;
					default:
						log.error("please enter valid choice between 1-10");
					}

				} catch (Exception e) {
					System.out.println("should contain only digits");
					companyManagerController();
				}
			} while (true);

		} catch (Exception e) {
			System.out.println("enter valid email and password");
			companyManagerController();
		}

	}

}
