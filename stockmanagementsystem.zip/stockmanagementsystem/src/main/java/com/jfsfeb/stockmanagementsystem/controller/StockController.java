package com.jfsfeb.stockmanagementsystem.controller;

import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.regex.Pattern;
import lombok.extern.log4j.Log4j;



@Log4j
public class StockController {
	public static void operations() {
		
			@SuppressWarnings("resource")
			Scanner scanner = new Scanner(System.in);

			do {
				try {
					log.info("*******WELCOME TO STOCK MANAGEMENT SYSTEM********");
					log.info("Press 1 For Admin ");
					log.info("press 2 For Manager ");
					log.info("Press 3 For Investor ");
					log.info("**************************************************");

					int i = scanner.nextInt();
					
					if(Pattern.matches("^[0-9]", String.valueOf(i)) ) {
						
						switch(i) {

						case 1:
							AdminController adminController= new AdminController();
							adminController.adminController();
							break;

						case 2:
							ManagerController managerContoller= new ManagerController();
							managerContoller.companyManagerController();
							break;

						case 3:
							InvestorController controller= new InvestorController();
							controller.investorController();
							break;

						default :
							log.error("enter choice between 1-3");
						}
					}else {
						log.error("please, enter numerics between 1-3 only!!");
					}
				}	catch (InputMismatchException e) {
					
					log.info("please enter valid input,should not contain alphabets");
					operations();
				}
			}while(true);

		}
 } 

