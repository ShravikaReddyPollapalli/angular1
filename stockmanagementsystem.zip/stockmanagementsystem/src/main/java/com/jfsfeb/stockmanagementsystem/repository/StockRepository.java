package com.jfsfeb.stockmanagementsystem.repository;

import java.util.ArrayList;
import java.util.List;

import com.jfsfeb.stockmanagementsystem.dto.AdminInfoBean;
import com.jfsfeb.stockmanagementsystem.dto.BuyStockInfoBean;
import com.jfsfeb.stockmanagementsystem.dto.CompanyInfoBean;
import com.jfsfeb.stockmanagementsystem.dto.ManagerInfoBean;
import com.jfsfeb.stockmanagementsystem.dto.StockInfoBean;
import com.jfsfeb.stockmanagementsystem.dto.UserInfoBean;

public class StockRepository {
	
	public static final List<StockInfoBean> stock = new ArrayList<StockInfoBean>(); 
	public static final List<AdminInfoBean> admin = new ArrayList<AdminInfoBean>();
	public static final List<UserInfoBean> user = new ArrayList<UserInfoBean>();
	public static final List<BuyStockInfoBean> request = new ArrayList<BuyStockInfoBean>();
	public static final List<ManagerInfoBean> manager = new ArrayList<ManagerInfoBean>();
	public static final List<CompanyInfoBean> company = new ArrayList<CompanyInfoBean>();
	
	
	public static void addToDataBase() {
		
	AdminInfoBean adminInfo = new AdminInfoBean();
	adminInfo.setId(403);
	adminInfo.setName("kalyani");
	adminInfo.setEmailId("kalyani@gmail.com");
	adminInfo.setMobileNumber(9502604245L);
	adminInfo.setPassword("Kalyani@12");
    admin.add(adminInfo);
    
    UserInfoBean userInfo = new UserInfoBean();
    userInfo.setUserId(414);
    userInfo.setUserName("bhagi");
    userInfo.setEmailId("bhagi@gmail.com");
    userInfo.setMobileNumber(9010616255L);
    userInfo.setPassword("Bhagi@12");
    user.add(userInfo);
    
    CompanyInfoBean companyInfo = new CompanyInfoBean();
    companyInfo.setCompanyId(1);
    companyInfo.setCompanyName("cadbury");
    company.add(companyInfo);
    
    ManagerInfoBean managerInfo = new ManagerInfoBean();
    managerInfo.setId(401);
    managerInfo.setName("sahith");
    managerInfo.setEmailId("sahith@gmail.com");
    managerInfo.setMobileNumber(6305614636l);
    managerInfo.setPassword("Sahith@12");
    manager.add(managerInfo);
    
    StockInfoBean stockInfo = new StockInfoBean();
    stockInfo.setId(1);
    stockInfo.setProductName("kitkat");
    stockInfo.setType("chocolate");
    stockInfo.setPrice(150.00);
    stockInfo.setQuantity(60);
    stock.add(stockInfo);
    
    StockInfoBean stockInfo1 = new StockInfoBean();
    stockInfo1.setId(2);
    stockInfo1.setProductName("oil");
    stockInfo1.setType("parachute");
    stockInfo1.setPrice(200.00);
    stockInfo1.setQuantity(67);
    stock.add(stockInfo1);
    
    BuyStockInfoBean buyStockInfoBean = new BuyStockInfoBean();
    buyStockInfoBean.setStockInfoBean(stockInfo);
    buyStockInfoBean.setUserInfoBean(userInfo);
	}
}
