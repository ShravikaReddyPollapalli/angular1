package com.jfsfeb.stockmanagementsystem.dto;

import lombok.Data;
import lombok.ToString;

@Data
public class UserInfoBean {
	
	private int userId;
	private String userName;
	private String emailId;
	@ToString.Exclude
	private String password;
	private long mobileNumber;
	
}