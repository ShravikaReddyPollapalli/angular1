package com.jfsfeb.stockmanagementsystem.dao;

import java.util.ArrayList;
import java.util.List;
import com.jfsfeb.stockmanagementsystem.dto.ManagerInfoBean;
import com.jfsfeb.stockmanagementsystem.dto.StockInfoBean;
import com.jfsfeb.stockmanagementsystem.exception.SMSException;
import com.jfsfeb.stockmanagementsystem.repository.StockRepository;

public class CompanyDAOImpl implements CompanyDAO {

	@Override
	public ManagerInfoBean loginManager(String email, String password) {
		for (ManagerInfoBean manager : StockRepository.manager) {
			if ((manager.getEmailId().equals(email)) && (manager.getPassword().equals(password))) {

				return manager;
			}
		}
		throw new SMSException("Invalid credentials");
	}

	@Override
	public boolean addStocks(StockInfoBean stockDetails) {
		for (StockInfoBean bean : StockRepository.stock) {
			if (bean.getId() == stockDetails.getId()) {
				return false;
			}
		}
		StockRepository.stock.add(stockDetails);
		return true;
	}

	@Override
	public List<StockInfoBean> searchStockByName(String productname) {
		List<StockInfoBean> searchList = new ArrayList<StockInfoBean>();
		for (int i = 0; i <= StockRepository.stock.size() - 1; i++) {
			StockInfoBean retrievedStock = StockRepository.stock.get(i);
			String retrievedPname = retrievedStock.getProductName();
			if (productname.equals(retrievedPname)) {
				searchList.add(retrievedStock);
				return searchList;
			}
		}
		if (searchList.size() == 0) {
			throw new SMSException("Stock not found");
		} else {
			return searchList;
		}
	}

	@Override
	public List<StockInfoBean> searchStockByType(String type) {
		List<StockInfoBean> searchList = new ArrayList<StockInfoBean>();
		for (int i = 0; i <= StockRepository.stock.size() - 1; i++) {
			StockInfoBean retrievedStock = StockRepository.stock.get(i);
			String retrievedType = retrievedStock.getType();
			if (type.equals(retrievedType)) {
				searchList.add(retrievedStock);
			}
		}
		if (searchList.size() == 0) {
			throw new SMSException("stock not found");
		} else {
			return searchList;
		}
	}

	@Override
	public List<StockInfoBean> searchStockByPrice(Double price) {
		List<StockInfoBean> searchList = new ArrayList<StockInfoBean>();
		for (int i = 0; i <= StockRepository.stock.size() - 1; i++) {
			StockInfoBean retrievedStock = StockRepository.stock.get(i);
			Double retrievedPrice = retrievedStock.getPrice();
			if (price.equals(retrievedPrice)) {
				searchList.add(retrievedStock);
			}
		}
		if (searchList.size() == 0) {
			throw new SMSException("Stock not found");
		} else {
			return searchList;
		}
	}

	@Override
	public boolean changePassword(long mobileNumber, String password) {
		ManagerInfoBean bean = new ManagerInfoBean();
		boolean updateStatus = false;
		for (int i = 0; i <= StockRepository.manager.size() - 1; i++) {
			ManagerInfoBean retrievedManager = StockRepository.manager.get(i);

			long retrievedNum = retrievedManager.getMobileNumber();
			if (mobileNumber == retrievedNum) {
				StockRepository.manager.remove(i);
				bean.setPassword(password);
				bean.setMobileNumber(mobileNumber);

				updateStatus = true;
				StockRepository.manager.add(bean);
				return updateStatus;
			}
		}

		return false;
	}

	@Override
	public List<StockInfoBean> getStockDetails() {
		// TODO Auto-generated method stub
		return StockRepository.stock;
	}

	@Override
	public boolean removeStocks(int id) {
		boolean removeStatus = false;
		for (int i = 0; i <= StockRepository.stock.size() - 1; i++) {
			StockInfoBean retrievedStock = StockRepository.stock.get(i);
			int retrievedId = retrievedStock.getId();
			if (id == retrievedId) {
				removeStatus = true;
				StockRepository.stock.remove(i);
				break;
			}
		}
		return removeStatus;

	}

	@Override
	public boolean updateStockTypeById(int id, String type) {
		StockInfoBean bean6 = new StockInfoBean();
		boolean updateStatus = false;
		for (int i = 0; i <= StockRepository.stock.size() - 1; i++) {
			StockInfoBean retrievedId = StockRepository.stock.get(i);
			int retrievedId1 = retrievedId.getId();
			if (id == (retrievedId1)) {
				StockRepository.stock.remove(i);
				bean6.setId(id);
				
				bean6.setType(type);
				updateStatus = true;
				StockRepository.stock.add(bean6);
				break;

			}
		}

		return updateStatus;
	}

	@Override
	public boolean updateStockPriceByName(String name, double price) {
		StockInfoBean bean6 = new StockInfoBean();
		boolean updateStatus = false;
		for (int i = 0; i <= StockRepository.stock.size() - 1; i++) {
			StockInfoBean retrievedSName = StockRepository.stock.get(i);
			String retrievedSName1 = retrievedSName.getProductName();
			if (name.equals(retrievedSName1)) {
				StockRepository.stock.remove(i);
				bean6.setProductName(name);
				bean6.setPrice(price);
				updateStatus = true;
				StockRepository.stock.add(bean6);
				break;

			}
		}

		return updateStatus;
	}

	@Override
	public boolean updateStockQuantityByType(String type, int quantity) {
		StockInfoBean bean6 = new StockInfoBean();
		boolean updateStatus = false;
		for (int i = 0; i <= StockRepository.stock.size() - 1; i++) {
			StockInfoBean retrievedType = StockRepository.stock.get(i);
			String retrievedType1 = retrievedType.getType();
			if (type.equals(retrievedType1)) {
				StockRepository.stock.remove(i);
				bean6.setType(type);
				bean6.setPrice(quantity);
				updateStatus = true;
				StockRepository.stock.add(bean6);
				break;
			}
		}

		return updateStatus;

	}
}
