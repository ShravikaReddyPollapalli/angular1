package com.jfsfeb.stockmanagementsystem.factory;

import com.jfsfeb.stockmanagementsystem.dao.AdminDAO;
import com.jfsfeb.stockmanagementsystem.dao.AdminDAOImpl;
import com.jfsfeb.stockmanagementsystem.dao.CompanyDAO;
import com.jfsfeb.stockmanagementsystem.dao.CompanyDAOImpl;
import com.jfsfeb.stockmanagementsystem.dao.UserDAO;
import com.jfsfeb.stockmanagementsystem.dao.UserDAOImpl;
import com.jfsfeb.stockmanagementsystem.service.AdminService;
import com.jfsfeb.stockmanagementsystem.service.AdminServiceImpl;
import com.jfsfeb.stockmanagementsystem.service.CompanyService;
import com.jfsfeb.stockmanagementsystem.service.CompanyServiceImpl;
import com.jfsfeb.stockmanagementsystem.service.UserService;
import com.jfsfeb.stockmanagementsystem.service.UserServiceImpl;
import com.jfsfeb.stockmanagementsystem.validation.Validation;
import com.jfsfeb.stockmanagementsystem.validation.ValidationImpl;

public class Factory {
	private Factory() {

	}

	public static AdminDAO getAdminDAOImplInstance() {
		AdminDAO dao = new AdminDAOImpl();
		return dao;
	}

	public static UserDAO getUserDAOImplInstance() {
		UserDAO userDao = new UserDAOImpl();
		return userDao;
	}

	public static CompanyDAO getCompanyDAOImplInstance() {
		CompanyDAO companyDao = new CompanyDAOImpl();
		return companyDao;
	}

	public static AdminService getAdminServiceImplInstance() {
		AdminService adminService = new AdminServiceImpl();
		return adminService;
	}

	public static CompanyService getCompanyServiceImplInstance() {
		CompanyService companyService = new CompanyServiceImpl();
		return companyService;
	}

	public static UserService getUserServiceImpl() {
		UserService userService = new UserServiceImpl();
		return userService;
	}
	
	public static Validation getValidationInstance() {
		Validation validation = new ValidationImpl();
		return validation;
	}
}
