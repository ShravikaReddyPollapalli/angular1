package com.jfsfeb.stockmanagementsystem.service;

import java.util.List;
import com.jfsfeb.stockmanagementsystem.dao.CompanyDAO;
import com.jfsfeb.stockmanagementsystem.dto.ManagerInfoBean;
import com.jfsfeb.stockmanagementsystem.dto.StockInfoBean;
import com.jfsfeb.stockmanagementsystem.factory.Factory;
import com.jfsfeb.stockmanagementsystem.validation.Validation;

public class CompanyServiceImpl implements CompanyService {

	CompanyDAO dao = Factory.getCompanyDAOImplInstance();

	Validation validation = Factory.getValidationInstance();

	@Override
	public ManagerInfoBean loginManager(String email, String password) {
		if(email!=null && password !=null) {
			if(validation.validatedEmail(email)) {
				if(validation.validatedPassword(password)) {
					return dao.loginManager(email, password);
				}
			}

		}
		return null;
	}

	@Override
	public boolean addStocks(StockInfoBean stockBean) {
		if(stockBean != null) {
			if(validation.validatedId(stockBean.getId())) {
				if(validation.validatedName(stockBean.getProductName())) {
					if(validation.validatedName(stockBean.getType())) {
						if(validation.validatedId(stockBean.getQuantity())) {
			                return dao.addStocks(stockBean);
						}
					}
				}
			}
		}
		return false;
	}

	@Override
	public List<StockInfoBean> searchStockByName(String productName) {
		  if(productName != null) {
		    	if(validation.validatedName(productName)) {
			           return dao.searchStockByName(productName);
		    	}
		    }
			return null;
		
	}

	@Override
	public List<StockInfoBean> searchStockByType(String type) {
		if(type != null) {
			if(validation.validatedName(type)) {
				return dao.searchStockByType(type);
			}
		}
		return null;
	}

	@Override
	public List<StockInfoBean> searchStockByPrice(Double price) {
		// TODO Auto-generated method stub
		return dao.searchStockByPrice(price);
	}

	@Override
	public boolean changePassword(long regMobile, String regPassword) {
		if(regMobile !=0 && regPassword!=null) {
			if(validation.validatedMobile(regMobile)) {
				if(validation.validatedPassword(regPassword)) {
					return dao.changePassword(regMobile, regPassword);
				}
			}
		}
		return false;
	}

	@Override
	public List<StockInfoBean> getStockDetails() {
		// TODO Auto-generated method stub
		return dao.getStockDetails();
	}

	@Override
	public boolean removeStocks(int id) {
		if(id !=0) {
			if(validation.validatedId(id)) {
			return dao.removeStocks(id);
			}
		}
		return false;
	}

	@Override
	public boolean updateStockTypeById(int id, String type) {
		if(id!=0 && type != null) {
			if(validation.validatedId(id)) {
				if(validation.validatedName(type)) {
					return dao.updateStockTypeById(id, type);
				}
			}
		}
		return false;
	}

	@Override
	public boolean updateStockPriceByName(String name, double price) {
		if(name != null && price !=0.0) {
			if(validation.validatedName(name)) {
				return dao.updateStockPriceByName(name, price);
			}
		}
		return false;
	}

	@Override
	public boolean updateStockQuantityByType(String type, int quantity) {
		if(type != null && quantity !=0) {
			if(validation.validatedName(type)) {
				return dao.updateStockQuantityByType(type, quantity);
			}
		}
	return false;
	}

	@Override
	public boolean updateManager(String mail, long phnum) {
		// TODO Auto-generated method stub
		return false;
	}

}
