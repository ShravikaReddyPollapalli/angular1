package com.jfsfeb.stockmanagementsystem.service;

import java.util.List;

import com.jfsfeb.stockmanagementsystem.dto.AdminInfoBean;
import com.jfsfeb.stockmanagementsystem.dto.CompanyInfoBean;
import com.jfsfeb.stockmanagementsystem.dto.ManagerInfoBean;

public interface AdminService {

	boolean registerManager(ManagerInfoBean managerInfoBean);

	boolean removeManager(int id);

	boolean updateManager(String mail, long phnum);

	boolean addCompany(CompanyInfoBean companyInfoBean);

	boolean removeCompany(String name);

	boolean updateCompany(int id, String cName);

	boolean registerAdmin(AdminInfoBean admin);

	List<ManagerInfoBean> getAllCompanyManagerInfo();

	AdminInfoBean authenticateAdmin(String email, String password);

	List<CompanyInfoBean> getAllCompanies();

}
