package com.jfsfeb.stockmanagementsystem.dto;

import java.io.Serializable;

import lombok.Data;

@SuppressWarnings("serial")
@Data
public class StockInfoBean implements Serializable {
	
	   private int id;
	   private String productName;
	   private String type;
	   private double price;
	   private int quantity;
	   
}