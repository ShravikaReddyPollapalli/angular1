package com.jfsfeb.stockmanagementsystem.service;

import java.util.List;
import com.jfsfeb.stockmanagementsystem.dao.UserDAO;
import com.jfsfeb.stockmanagementsystem.dto.BuyStockInfoBean;
import com.jfsfeb.stockmanagementsystem.dto.StockInfoBean;
import com.jfsfeb.stockmanagementsystem.dto.UserInfoBean;
import com.jfsfeb.stockmanagementsystem.factory.Factory;
import com.jfsfeb.stockmanagementsystem.validation.Validation;

public class UserServiceImpl implements UserService {
	UserDAO dao = Factory.getUserDAOImplInstance();
	Validation validation = Factory.getValidationInstance();

	@Override
	public UserInfoBean loginUser(String email, String password) {
		if (email != null && password != null) {
			if (validation.validatedEmail(email)) {
				if (validation.validatedPassword(password)) {
					return dao.loginUser(email, password);
				}
			}
		}
		return null;
	}

	@Override
	public boolean changePassword(long regMobile, String regPassword) {
		// TODO Auto-generated method stub
		return dao.changePassword(regMobile, regPassword);
	}

	@Override
	public boolean registerUser(UserInfoBean user) {
		if (user != null) {
			if (validation.validatedId(user.getUserId())) {
				if (validation.validatedName(user.getUserName())) {
					if (validation.validatedMobile(user.getMobileNumber())) {
						if (validation.validatedEmail(user.getEmailId())) {
							if (validation.validatedPassword(user.getPassword())) {
								return dao.registerUser(user);
							}
						}
					}
				}
			}
		}
		return false;
	}

	@Override
	public BuyStockInfoBean buyRequest(UserInfoBean user, StockInfoBean stockBean) {
		// TODO Auto-generated method stub
		return dao.buyRequest(user, stockBean);
	}

	@Override
	public List<StockInfoBean> searchProductByType(String type) {
		if (type != null) {
			if (validation.validatedName(type)) {
				return dao.searchProductByType(type);
			}
		}
		return null;
	}

	@Override
	public List<StockInfoBean> searchProductByName(String name) {
		if (name != null) {
			if (validation.validatedName(name)) {
				return dao.searchProductByName(name);
			}
		}
		return null;
	}

	@Override
	public List<StockInfoBean> getAllStockInfo() {
		// TODO Auto-generated method stub
		return dao.getAllStockInfo();
	}

	@Override
	public boolean updateManager(String mail, long mobile) {
		if (mail != null && mobile != 0) {
			if (validation.validatedEmail(mail)) {
				if (validation.validatedMobile(mobile)) {
					return dao.updateManager(mail, mobile);
				}
			}
		}
		return false;

	}
}
