import { CompaniesPipe } from './companies.pipe';

describe('CompaniesPipe', () => {
  it('create an instance', () => {
    const pipe = new CompaniesPipe();
    expect(pipe).toBeTruthy();
  });
});
