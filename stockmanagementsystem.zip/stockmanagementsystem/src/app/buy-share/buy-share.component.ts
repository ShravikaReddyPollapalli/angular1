import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-buy-share',
  templateUrl: './buy-share.component.html',
  styleUrls: ['./buy-share.component.css']
})
export class BuyShareComponent implements OnInit {

  constructor(public userService: UserService,
              private router: Router) { }
  success: any;
  failure: any;

  isTrue: false;

  ngOnInit() {
  }
  setPrice() {
    
    this.userService.selectedCompanyToUpdate.price =   this.userService.selectedCompanyToUpdate.quantity *  this.userService.selectedCompanyToUpdate.bidPrice;
  }

  setQuantity() {
    if(this.userService.selectedCompanyToUpdate.maxStockQuantity > this.userService.selectedCompanyToUpdate.quantity) {
    return this.isTrue;
    }
  }

  buyshare(price) {

    const userDetails = JSON.parse(localStorage.getItem('userDetails'));
    console.log(userDetails);
    const rqObj = {
      userId: userDetails.user[0].userId,
      companyId: this.userService.selectedCompanyToUpdate.companyId,
      totalSharesTransacted: this.userService.selectedCompanyToUpdate.quantity,
      totalAmount: this.userService.selectedCompanyToUpdate.price
    };

    console.log(rqObj);
    this.userService.addShare(rqObj).subscribe(data => {

      if (data.statusCode === 201) {
        console.log(data);
        this.success = data.description;
      } else {
        console.log(data);
        this.failure = data.description;
      }
      setTimeout(() => {
        this.success = null;
        this.failure = null;
      }, 2000);
      this.router.navigateByUrl('/investor-company');
    });
  }
}
