import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-investor-share',
  templateUrl: './investor-share.component.html',
  styleUrls: ['./investor-share.component.css']
})
export class InvestorShareComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
