import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-companymanager',
  templateUrl: './companymanager.component.html',
  styleUrls: ['./companymanager.component.css']
})
export class CompanymanagerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
