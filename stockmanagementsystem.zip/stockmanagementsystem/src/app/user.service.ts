import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  userId;
  
  userEmail;
  selectedCompanyToUpdate;
  selectedStockToUpdate;
  selectedManagerToUpdate;
  selectedSharesToUpdate;
  apiUrl = 'http://localhost:8080';
  userName;
  constructor(private http: HttpClient) { }
  
  login(user: any): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/login`, user);
   }
   getAllManagersData(): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/view-all-users`);
  }
  getAllCompaniesData(): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/get-allcompanies`);
  }
  getAllSharesData(shareDetails: any): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/get-allshares/${shareDetails}`);
  }
  getAllStocksData(): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/get-allstocks`);
  }

  addCompanyData(company): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/add-company`, company);
  }
  addManagerData(user): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/register`, user);
  }
  addUserData(user): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/register`, user);
  }
  addStockData(stock): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/add-stock`, stock);
  }
  
  deleteManagerData(user: any): Observable<any> {
    return this.http.delete<any>(`${this.apiUrl}/delete-user/${user.userId}`);
  }
  deleteCompanyData(company: any): Observable<any> {
    return this.http.delete<any>(`${this.apiUrl}/delete-company/${company.companyId}`);
  }
  deleteStockData(stock: any): Observable<any> {
    return this.http.delete<any>(`${this.apiUrl}/delete-stock/${stock.stockId}`);
  }
  updateCompanyData(company: any): Observable<any> {
    return this.http.put<any>(`${this.apiUrl}/update-company/${company.companyId}`,company);
  }
  updateStockData(stock: any): Observable<any> {
    return this.http.put<any>(`${this.apiUrl}/update-stock/${stock.stockId}`,stock);
  }
  updateManagerData(manager: any): Observable<any> {
    return this.http.put<any>(`${this.apiUrl}/change-password`,manager);
  }
  forgotPassword(manager: any): Observable<any> {
    return this.http.put<any>(`${this.apiUrl}/change-password`,manager);
  }
  addShare(reqObj): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/add-share`, reqObj);
  }

  sellShare(reqObj): Observable<any> {
    return this.http.put<any>(`${this.apiUrl}/sell-share`, reqObj);
  }

  buyShare(reqObj): Observable<any> {
    return this.http.put<any>(`${this.apiUrl}/buy-share`, reqObj);
  }
}

