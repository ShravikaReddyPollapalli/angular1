interface Company{
    companyId: string;
     companyName: string;
     stockAvailability: number;
     totalQuantity: number;
     bidPrice: number;
     maxStockAmount: number;
     maxStockQuantity: number;
 }