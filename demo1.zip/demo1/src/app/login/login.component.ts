import { Component, OnInit, OnDestroy } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit, OnDestroy {
    name='shra';
    siteUrl= window.location.href;
    
  constructor() { 
    console.log('this is constructor of login');
  }

  ngOnInit() {
    console.log('this is ngOnInit of login');
  }
  
  ngOnDestroy() {
    console.log('this is ngOnDestroy of login');
  } 
  user(){
    return "hello" + this.name;
  }
}
