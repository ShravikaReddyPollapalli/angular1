import { Component, OnInit, OnDestroy } from '@angular/core';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit,OnDestroy {

  constructor() {
    console.log('this is constructor of register');
   }

  ngOnInit() {
    console.log('this is ngOnInit of Register');
  }

  ngOnDestroy() {
    console.log('this is ngOnDestroy of register');
  }
}
