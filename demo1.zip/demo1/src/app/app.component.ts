import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  name = 'demo1';
  
  //a:number;
  //b:number;
  isDisabled:boolean=false;
  add=(a=10,b=20)=>{
    let add = a+b;
    console.log(add);
  }
  sub=(a=10,b=20)=>{
    let sub = a-b;
    console.log(sub);
  }
  mul=(a,b)=>{
    let mul = a*b;
    console.log(mul);
  }
  // add=(a=10,b=20)=>{
  //   let add = a+b;
  //   console.log(add);
  // }
  a:number;
  b:number;
  add1=(a:number,b:number)=>{
    a=Number(prompt('enter a'));
b=Number(prompt('enter b'));
alert(a+b);
  }
  sub1=(a:number,b:number)=>{
    a=Number(prompt('enter a'));
b=Number(prompt('enter b'));
alert(a-b);
  }
  mul1=(a:number,b:number)=>{
    a=Number(prompt('enter a'));
b=Number(prompt('enter b'));
alert(a*b);
  }
}

