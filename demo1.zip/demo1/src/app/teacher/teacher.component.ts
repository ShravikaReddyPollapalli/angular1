import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-teacher',
  templateUrl: './teacher.component.html',
  styleUrls: ['./teacher.component.css']
})
export class TeacherComponent implements OnInit {


  
  constructor() { }

  ngOnInit() {
  }
  recieve(result){
    console.log(result);
  }
//step1 of P to C
homework:string = 'angular';
}
