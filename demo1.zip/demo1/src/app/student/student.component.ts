import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';



@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {

  constructor() { }
  @Input() task

//step1 c to p
  result = "task is completed";
  //step2 c to p
  @Output() submit = new EventEmitter();
  ngOnInit() {
    console.log(this.task);
    //step3 c to p
    this.submit.emit(this.result)
  }
 
 
}
