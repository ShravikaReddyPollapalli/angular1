import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class RocketService {
rocketName='gslv4';
getSoil(){
  console.log('done')
}
  constructor() { }
}
