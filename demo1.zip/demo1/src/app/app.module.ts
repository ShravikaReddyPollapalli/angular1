import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
// import {  RouterModule,Routes} from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { TreeComponent } from './tree/tree.component';
import { TeacherComponent } from './teacher/teacher.component';
import { StudentComponent } from './student/student.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { HeaderComponent } from './header/header.component';
import { RocketComponent } from './rocket/rocket.component';
import { DemoComponent } from './demo/demo.component';
import { DataComponent } from '../../../project2/src/app/data/data.component';

// //step 2
//  let routes:Routes=[
//   {path:'login',component:LoginComponent},
//   {path:'register',component:RegisterComponent, children:[
//     {path:'login',component:LoginComponent}
//   ] },
//   {path:'**',redirectTo:"'login"}
//  ];
@NgModule({
  declarations: [
    AppComponent,
    // TreeComponent,
    // TeacherComponent,
    // StudentComponent,
     LoginComponent,
    // RegisterComponent,
    // HeaderComponent,
    // RocketComponent,
    // DemoComponent,
    // DataComponent
  ],
  imports: [
    BrowserModule,
    // FormsModule,
    // //step 3
    // RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
 
})
export class AppModule { }
