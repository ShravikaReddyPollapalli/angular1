import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminregisterComponent } from './adminregister.component';



@NgModule({
  declarations: [AdminregisterComponent],
  imports: [
    CommonModule
  ],
  exports: [AdminregisterComponent]
})
export class AdminregisterModule { }
