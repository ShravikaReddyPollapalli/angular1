import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminregister',
  templateUrl: './adminregister.component.html',
  styleUrls: ['./adminregister.component.css']
})
export class AdminregisterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
