import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {  RouterModule,Routes} from '@angular/router';
import { AppComponent } from './app.component';
import { LoginModule } from './login/login.module';
import { HomeModule } from './home/home.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LoginComponent } from './login/login.component';
import { AddbookModule } from './addbook/addbook.module';
import { AddbookService } from './addbook.service';
import { AddbookComponent } from './addbook/addbook.component';

import { HttpClientModule, HttpClient } from '@angular/common/http';
import { AdminregisterModule } from './adminregister/adminregister.module';
import { AdminregisterComponent } from './adminregister/adminregister.component';
import { AdminrComponent } from './adminr/adminr.component';
import { AdminrModule } from './adminr/adminr.module';
let routes:Routes=[
    {path:'login',component:LoginComponent},
    {path:'addbook',component:AddbookComponent},
    {path:'adminregister' ,component:AdminregisterComponent},
    {path:'adminr',component:AdminrComponent}

]

@NgModule({
  declarations: [
    AppComponent,
    
  ],
  imports: [
    BrowserModule,
    LoginModule,
    HomeModule,
    AddbookModule,
    FormsModule,
    AdminregisterModule,
    AdminrModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule.forRoot(routes)
  ],
  providers: [AddbookService],
  bootstrap: [AppComponent]
})
export class AppModule { }
