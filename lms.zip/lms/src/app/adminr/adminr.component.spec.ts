import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminrComponent } from './adminr.component';

describe('AdminrComponent', () => {
  let component: AdminrComponent;
  let fixture: ComponentFixture<AdminrComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminrComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminrComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
