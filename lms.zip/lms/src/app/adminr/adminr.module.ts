import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminrComponent } from './adminr.component';



@NgModule({
  declarations: [AdminrComponent],
  imports: [
    CommonModule
  ],
  exports: [AdminrComponent]
})
export class AdminrModule { }
