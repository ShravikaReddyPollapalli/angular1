import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminr',
  templateUrl: './adminr.component.html',
  styleUrls: ['./adminr.component.css']
})
export class AdminrComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
