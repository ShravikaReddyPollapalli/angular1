import { Injectable } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class AddbookService {
  // getUsers: any;
  // getUsers(): any {
  //   throw new Error("Method not implemented.");
  // }

  constructor() { }
  getAllUsers(){
      return [
        {Accountno:1,BookTitle:"Core Python Programming",Category:'Computer',author:"R.Nageshwar",bookpublisher:"Person",ISBN:"0-131257",copyright:"2014",dateadded:"2013-12-11"},
        {Accountno:2,BookTitle:"",Category:'Computer',author:"",bookpublisher:"",ISBN:"",copyright:"",dateadded:""},
        {Accountno:3,BookTitle:"Elements Of ElectroMagnetic",Category:'Electronics',author:"A.K.Ray",bookpublisher:"Marshall",ISBN:"1-6393",copyright:"2015",dateadded:"2016-01-07"},
        {Accountno:4,BookTitle:"Antenna and wavepropagation",Category:'Electronics',author:"K.D.Prasad",bookpublisher:"edu corporation",isbn:"34445",copyright:"2012",dateadded:"2014-11-1"},
        {Accountno:5,BookTitle:"Signals and Systems",Category:'Electronics',author:"M.D.surya",bookpublisher:"pearson",isbn:"34445",copyright:"2001",dateadded:"2003-11-1"}
             ];
}
// url : string ='http://localhost:3000/users/';
//  getUsers(){
//    return this.http.get(this.url);
//  }
}







// Core Python Programming	computer science	R. Nageswara Rao	20	Pearson Education Inc	Prentice	0-131257	2014	2013-12-11	new	
// 2	Digital Siginal Processing	Electronics	Proakis	5	Marshall corporation	Marshall	1-6393	2015	2017-04-12	old	
// 3	Elements of Electromagnetics	Electronics	A.K.Ray	10	Pearson corporation	Pearson	12345	2011	2016-01-07	new	
// 4	Antenna and wave propagation	Electronics	K.D.Prasad	23	edu corporation	edu	21321	1991	2011-11-1	old	
// 5	Signals and Systems	Electronics	M.D.surya	11	pearson corporation	Pearson	34445	2001	2003-8-4	new	
// 6	Computer Networks	Computer science	M.K.surya	32	marsall corporation	Marshall	234456	2002	2003-4-2	old