import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddbookComponent } from './addbook.component';



@NgModule({
  declarations: [AddbookComponent],
  imports: [
    CommonModule
  ],
  exports:[
    AddbookComponent
  ]
})
export class AddbookModule { }
