import { Component, OnInit } from '@angular/core';
import { AddbookService } from '../addbook.service';

@Component({
  selector: 'app-addbook',
  templateUrl: './addbook.component.html',
  styleUrls: ['./addbook.component.css']
})
export class AddbookComponent implements OnInit {
  users: any;
  

  constructor(private addService:AddbookService) { }

  // columns = ["Account no","Book Title","Category","Author"];
  // index = ["accountno", "booktitle", "category", "author"];

  ngOnInit() {
    this.users=this.addService.getAllUsers();
      
    }
  // ngOnInit():void {
  //   this.addService.getUsers().subscribe
  //   (
  //   (Response)=>
  //   {
  //     this.users = Response;
  //   },
  //   (error)=> console.log(error)
  //   )
  // }
  }


