export class Users 
{
    accountNo:string;
            bookTitle:string;
            category:string;
          author:string;

          constructor(accountNo,bookTitle,category,author)
          {
              this.accountNo = accountNo;
              this.bookTitle = bookTitle;
              this.category = category;
              this.author = author;

          }
}