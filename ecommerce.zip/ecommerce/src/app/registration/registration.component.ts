import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { customValidators } from './Validation';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  constructor(private builder: FormBuilder,private router:Router) { }
  regGroup;

  ngOnInit() {
    this.regGroup = this.builder.group({
      username:['',[Validators.required,Validators.minLength(4)]],
      pass:['',[Validators.required]],
      confirmPass:['',[Validators.required]]
    },{ validators:customValidators})
  }
submit(){
  console.log(this.regGroup.value);
  let userDetails = JSON.stringify(this.regGroup.value);
  localStorage.setItem(this.regGroup.value.username,userDetails);
  this.router.navigate(['/login']);
}
}
