import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeComponent } from './home.component';
import { CartComponent } from './cart/cart.component';
import { OffersComponent } from './offers/offers.component';
import { PaymentsComponent } from './payments/payments.component';



@NgModule({
  declarations: [HomeComponent, CartComponent, OffersComponent, PaymentsComponent],
  imports: [
    CommonModule
  ]
})
export class HomeModule { }
