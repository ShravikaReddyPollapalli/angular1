import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RegistrationComponent } from './registration/registration.component';
import { RegistrationModule } from './registration/registration.module';
import { LoginComponent } from './login/login.component';
import { LoginModule } from './login/login.module';
import { HomeComponent } from './home/home.component';
import { HomeModule } from './home/home.module';
import { CartComponent } from './home/cart/cart.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


const routes: Routes = [
  {path:"login",component:LoginComponent},
  {path:"registration" , component:RegistrationComponent}, 
  // {path:"home",component:HomeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes),
    RegistrationModule,
    LoginModule,
    //  HomeModule  
    FormsModule,ReactiveFormsModule
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
