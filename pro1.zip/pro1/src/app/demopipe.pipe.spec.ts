import { DemopipePipe } from './demopipe.pipe';

describe('DemopipePipe', () => {
  it('create an instance', () => {
    const pipe = new DemopipePipe();
    expect(pipe).toBeTruthy();
  });
});
