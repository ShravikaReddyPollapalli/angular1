import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-binding',
  templateUrl: './binding.component.html',
  styleUrls: ['./binding.component.css']
})
export class BindingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
pageTitle:string=" this is using interpolation";
imageUrl:string="assets/download.png";
btnStatus:boolean=false;
changeTitle(){
  this.pageTitle="new name";
}
}
