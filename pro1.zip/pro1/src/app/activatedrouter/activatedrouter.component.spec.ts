import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActivatedrouterComponent } from './activatedrouter.component';

describe('ActivatedrouterComponent', () => {
  let component: ActivatedrouterComponent;
  let fixture: ComponentFixture<ActivatedrouterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActivatedrouterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivatedrouterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
