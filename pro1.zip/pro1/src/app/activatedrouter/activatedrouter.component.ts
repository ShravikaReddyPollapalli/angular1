import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-activatedrouter',
  templateUrl: './activatedrouter.component.html',
  styleUrls: ['./activatedrouter.component.css']
})
export class ActivatedrouterComponent implements OnInit {
id
user
  constructor(private activate:ActivatedRoute) {
    this.activate.params.subscribe(data =>{
      console.log(data);
      this.id= data.id;
    });
    this.activate.queryParams.subscribe(data => {
      console.log(data);
      this.user = data ;
    })
   }

  ngOnInit() {
  }

}
