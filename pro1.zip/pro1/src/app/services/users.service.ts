import { Injectable } from '@angular/core';
import { HttpClientModule, HttpClient } from '@angular/common/http';



import "rxjs/add/observable/throw";
import  {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
@Injectable({
  providedIn: 'root'
})
export class UsersService {

  // constructor() { }
  // getAllUsers(){
  //   return [
  //     {id:3,name:"qwe",city:'banglore',salary:30000,dob:new Date("05/04/1998")},
  //         {id:4,name:'asd',city:'hyd',salary:45666,dob:new Date("08/5/1996")},
  //        {id:5,name:'zxc',city:'delhi',salary:60,dob:new Date("9/10/1999")},
  //          {id:6,name:'poi',city:'goa',salary:98476,dob:new Date("9/9/1994")}
  //          ];
  //         //  this is the data which should be used across the component
  //         //next step is declaration in providers
  // }


  constructor(private http:HttpClient) {}
  getAllUsers() {
    return this.http.get('https://jsonplaceholder.typicode.com/userss')
    .catch((error)=>{
      console.log(error);
      return Observable.throw(error);
    })
  }
}
