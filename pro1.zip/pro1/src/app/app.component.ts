import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { VegComponent } from './veg/veg.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent{
  title = 'angularproject1';
  constructor(private route:Router){
  }
  veg=()=>{
    
    this.route.navigate(['veg']);
    document.write('welcome to veg family');
  }
}