import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-directives',
  templateUrl: './directives.component.html',
  styleUrls: ['./directives.component.css']
})
export class DirectivesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  } 
// users:string[]=["hi","shra","reddy"];//simple name of users
// users:any[]=[
//   {id:101,name:'shra',city:'bglore'},
//   {id:101,name:'shra',city:'bglore'},
//   {id:101,name:'shra',city:'bglore'}
// ];//array of objects i.e.,key and value
// isUserLoggedIn=true;
// isUserLoggedIn:boolean=true;
// isUserLoggedIn:boolean=false;
// toggle(){
//   this.isUserLoggedIn = !this.isUserLoggedIn;
// }
selectedCountry:string;
countries:any[]=[
  {code:'in',country:'india'},
  {code:'aus',country:'australia'}
]
choice(code){
  this.selectedCountry=code;
}
}
