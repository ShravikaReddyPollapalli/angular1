import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-veg',
  templateUrl: './veg.component.html',
  styleUrls: ['./veg.component.css']
})
export class VegComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }
 
  routeToStarter = () => {
    this.router.navigate(['veg/starter']);
  }
routeToMainCourse = () => {
  this.router.navigate(['veg/maincourse']);
}
}
