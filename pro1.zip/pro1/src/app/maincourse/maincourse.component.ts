import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-maincourse',
  templateUrl: './maincourse.component.html',
  styleUrls: ['./maincourse.component.css']
})
export class MaincourseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
