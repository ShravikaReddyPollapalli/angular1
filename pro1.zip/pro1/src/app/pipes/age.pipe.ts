import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'age'
})
export class AgePipe implements PipeTransform {

  transform(value: any): any {
    let currentYear = new Date().getFullYear();//2019
    let givenYear = new Date(value).getFullYear();
    let age= currentYear-givenYear;
    return age
    ;
  }

}
