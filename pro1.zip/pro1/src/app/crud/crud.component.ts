import { Component, OnInit } from '@angular/core';

import { CrudService } from '../crud.service';
@Component({
  selector: 'app-crud',
  templateUrl: './crud.component.html',
  styleUrls: ['./crud.component.css']
})
export class CrudComponent implements OnInit {
employeeData;
  constructor(private service: CrudService) { }

  ngOnInit() {
  }
 getDataFromService(){ 
  console.log('this is ts');
  // this.employeeData = this.service.getDataFromAPI();
  // console.log(this.employeeData);

  const observable = this.service.getDataFromAPI();
  observable.subscribe((response) => {
    this.employeeData = response['data'];
    console.log(this.employeeData);
  })
}
postDataToService() {
  const observable=this.service.postDataToAPI();
  observable.subscribe((response)=>{
    console.log(response);
  })
}


PutDataToService(){
  const observable=this.service.putDataToAPI();
  observable.subscribe((response)=>{
    console.log(response);
  })
}
DeleteDataFromService(){
  const observable=this.service.deleteDataFromAPI();
  observable.subscribe((response)=>{
    console.log(response);
  })
}
}
