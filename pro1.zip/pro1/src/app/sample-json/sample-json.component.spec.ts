import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SampleJsonComponent } from './sample-json.component';

describe('SampleJsonComponent', () => {
  let component: SampleJsonComponent;
  let fixture: ComponentFixture<SampleJsonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SampleJsonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SampleJsonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
