import { Component, OnInit } from '@angular/core';
import{ HttpClient }  from '@angular/common/http';
@Component({
  selector: 'app-sample-json',
  templateUrl: './sample-json.component.html',
  styleUrls: ['./sample-json.component.css']
})
export class SampleJsonComponent implements OnInit {
  search:string;
  data;

  constructor(private http:HttpClient) { 
  this.readJson();
  }
   shra;
  ngOnInit() {
   
  }

  readJson(){
    this.http.get('assets/product.json').subscribe((data)=>{
    console.log(data);
    this.shra=data;
  })
  }
}
