import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'demopipe'
})
export class DemopipePipe implements PipeTransform {

  transform(value ): any {
    let firstname=value.charAt(0);
     let upper = firstname.toUpperCase();
     console.log(upper);

     let slice = value.slice(2);
     console.log(slice);
     let output = upper+slice;
     return output;
  }

}
