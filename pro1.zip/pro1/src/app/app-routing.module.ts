import { NgModule } from '@angular/core';
import { Routes, RouterModule, ActivatedRoute } from '@angular/router';
import { VegComponent } from './veg/veg.component';
import { StarterComponent } from './starter/starter.component';
import { MaincourseComponent } from './maincourse/maincourse.component';
import { RouterComponent } from './router/router.component';
import { ActivatedrouterComponent } from './activatedrouter/activatedrouter.component';
import { from } from 'rxjs';
import { CrudComponent } from './crud/crud.component';
import { TemplateComponent } from './template/template.component';
import { FormsModule } from '@angular/forms';
import { SampleJsonComponent } from './sample-json/sample-json.component';
import { ReactiveComponent } from './reactive/reactive.component';
import { HeaderComponent } from './header/header.component';
import { DemoComponent } from './demo/demo.component';


const routes: Routes = [
  {
    path: 'veg', component: VegComponent, children: [
      { path: 'starter', component: StarterComponent },
      { path: 'maincourse', component: MaincourseComponent }
    ]
  },
  { path: 'router', component: RouterComponent },
  { path: 'activated-router/:id', component: ActivatedrouterComponent }
  , { path: 'crud', component: CrudComponent },
  { path: 'header', component: HeaderComponent },
  { path: 'template', component: TemplateComponent },
  { path: 'reactive', component: ReactiveComponent },
  { path: 'header', component: HeaderComponent },
  { path: 'sample-json', component: SampleJsonComponent },
  { path: 'demo', component: DemoComponent },
   {path:'router',component:RouterComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule, FormsModule]

})
export class AppRoutingModule { }
