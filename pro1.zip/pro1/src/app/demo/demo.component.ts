import { Component, OnInit } from '@angular/core';
import { UsersService } from '../services/users.service';
import {Observable } from "rxjs/Observable";

@Component({
  selector: 'app-demo',
  templateUrl: './demo.component.html',
  styleUrls: ['./demo.component.css']
})
export class DemoComponent implements OnInit {
devName='shravika';


pageTitle:string = "pipes in angular";
errorMessage:string="loading;"
users;
  constructor(private userService:UsersService ) { }

  ngOnInit() {
    this.userService.getAllUsers().subscribe((data)=>{
      this.users=data;
    },(err)=>{
      // this.errorMessage="some";
      this.errorMessage=err.message;
    });
  }

}


// users=[{id:3,name:"qwe",city:'banglore',salary:30000,dob:new Date("05/04/1998")},
//       {id:4,name:'asd',city:'hyd',salary:45666,dob:new Date("08/5/1996")},
//       {id:5,name:'zxc',city:'delhi',salary:60,dob:new Date("9/10/1999")},
//       {id:6,name:'poi',city:'goa',salary:98476,dob:new Date("9/9/1994")}]