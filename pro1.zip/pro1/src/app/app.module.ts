import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { VegComponent } from './veg/veg.component';
import { StarterComponent } from './starter/starter.component';
import { MaincourseComponent } from './maincourse/maincourse.component';
import { RouterComponent } from './router/router.component';
import { ActivatedrouterComponent } from './activatedrouter/activatedrouter.component';
import { CrudComponent } from './crud/crud.component';
import { TemplateComponent } from './template/template.component';
 import { SampleJsonComponent } from './sample-json/sample-json.component';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HeaderComponent } from './header/header.component';
import { ReactiveComponent } from './reactive/reactive.component';
import { NavComponent } from './nav/nav.component';
 import { FilterPipe } from './filter.pipe';
import { DemoComponent } from './demo/demo.component';
import { DemopipePipe } from './demopipe.pipe';
import { AgePipe } from './pipes/age.pipe';
import { CrudService } from './crud.service';
import { Observable } from 'rxjs';
import { BindingComponent } from './binding/binding.component';
import { DirectivesComponent } from './directives/directives.component';



@NgModule({
  declarations: [
    AppComponent,
    VegComponent,
    StarterComponent,
    MaincourseComponent,
    RouterComponent,
    ActivatedrouterComponent,
    CrudComponent,
    TemplateComponent,
     SampleJsonComponent,
    HeaderComponent,
    ReactiveComponent,
    NavComponent,
     FilterPipe,
     DemoComponent,
    DemopipePipe,
    AgePipe,
    BindingComponent,
    DirectivesComponent
    
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule
  
  ],
  providers: [CrudService],
  bootstrap: [AppComponent]
})
export class AppModule { }
