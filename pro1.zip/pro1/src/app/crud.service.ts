import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class CrudService {
  
  constructor(private http:HttpClient) { }
getDataFromAPI() {
  console.log('this is service calling api');
  const observable = this.http.get('https://reqres.in/api/users?page=2');
  return observable;
}
postDataToAPI() {
let obj ={
  name:'priyanka',
  designation:'software',
  id:'45',
  quote:'iloveu'
}
const observable = this.http.post('https://reqres.in/api/users',obj);
return observable;
}
putDataToAPI(){
  let obj={
    name:'shravika',
    designation:'software'
  }
  const observable=this.http.put("https://reqres.in/api/users/2",obj);
  return observable;
}
deleteDataFromAPI(){
  let obj={
    name:'pavani',
    designation:'software'
  }
  const observable=this.http.delete("https://reqres.in/api/users/2");
  return observable;
}
}