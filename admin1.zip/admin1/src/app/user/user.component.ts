import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  

  constructor(private formBuilder: FormBuilder) { }
loginGroup;
  ngOnInit() {
  this.loginGroup= this.formBuilder.group({
     user_name:["",[Validators.required,Validators.minLength(5)]],
      password:["",[Validators.required,Validators.minLength(5)]]
      
    })
 }
 onSubmit(f:NgForm){
   console.log("user_name",f.value);
 }
}

  

