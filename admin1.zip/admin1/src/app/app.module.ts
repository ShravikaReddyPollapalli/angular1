import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {  RouterModule,Routes} from '@angular/router';
import { AppComponent } from './app.component';
import { UserModule } from './user/user.module';


import { FormGroup, FormControl, Validators, FormBuilder }  from '@angular/forms';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import { ListModule } from './list/list.module';
import { ListComponent } from './list/list.component';
import { UserComponent } from './user/user.component';


 let routes:Routes=[
      {path:'user',component:UserComponent},
{path:'list',component:ListComponent}]

@NgModule({
  declarations: [
    AppComponent,
    // UserComponent
  ],
  imports: [
    BrowserModule,
    UserModule,
    FormsModule,
    ReactiveFormsModule,
    ListModule
    
    
   
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
